package com.example.bottomnavactivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DoctorActivity : AppCompatActivity() {
    private val doctorButton: Button
        get() = findViewById(R.id.button4)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor)
        doctorButton.setOnClickListener {
            val intent1 = Intent(this, WebActivity::class.java)
            startActivity(intent1)
        }

    }
}