package com.example.bottomnavactivity

import android.widget.TextView
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity



class WelcomeActivity : AppCompatActivity() {
    private val welcome_header: TextView
        get() = findViewById(R.id.welcome_header)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        val welcomeUser = intent.getStringExtra(LOGIN_NAME_KEY)
        val welcomeMessage = getString(R.string.welcome_text, welcomeUser)
        welcome_header.text = welcomeMessage
    }
}