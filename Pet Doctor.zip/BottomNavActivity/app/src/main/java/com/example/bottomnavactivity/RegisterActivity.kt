package com.example.bottomnavactivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

const val REGISTER_NAME_KEY = "REGISTER_NAME_KEY"
const val REGISTER_PASSWORD_KEY = "REGISTER_PASSWORD_KEY"

class RegisterActivity : AppCompatActivity() {

    private val backButton: Button
        get() = findViewById(R.id.back_button)

    private val doneButton: Button
        get() = findViewById(R.id.done_button)

    private val registerName: EditText
        get() = findViewById(R.id.register_name)

    private val registerPassword: EditText
        get() = findViewById(R.id.register_password)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        doneButton.setOnClickListener{
            //          获取layout中user_name的值
            val registerName_get = registerName.text.toString().trim()
            val registerPassword_get = registerPassword.text.toString().trim()

//          调用隐藏键盘函数对键盘进行隐藏
            hideKeyboard()

//          进行判空处理
            if (registerName_get.isNotEmpty() && registerPassword_get.isNotEmpty()) {

                Intent(this, LoginActivity::class.java).also { registerIntent ->
                    //将数据加入intent中储存
                    registerIntent.putExtra(REGISTER_NAME_KEY, registerName_get)
                    registerIntent.putExtra(REGISTER_PASSWORD_KEY, registerPassword_get)

                    //Reset text fields to blank
                    this.registerName.text.clear()
                    this.registerPassword.text.clear()

                    //回到login界面
                    setResult(RESULT_OK,registerIntent)
                    finish()
                }

            } else {
                val toast = Toast.makeText(
                    this,
                    getString(R.string.register_form_entry_error),
                    Toast.LENGTH_LONG
                )
                toast.setGravity(Gravity.CENTER, 0, 0)
                toast.show()
            }
        }

        backButton.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }


    }

    //隐藏键盘
    private fun hideKeyboard() {
        if (currentFocus != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
        }
    }
}