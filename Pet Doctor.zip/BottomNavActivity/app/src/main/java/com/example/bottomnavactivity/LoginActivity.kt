package com.example.bottomnavactivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

const val LOGIN_NAME_KEY = "LOGIN_NAME_KEY"

class LoginActivity : AppCompatActivity() {
    private var returnRegisterName: String? = null
    private var returnRegisterPassword: String? = null

    private  val submitButton: Button
        get() = findViewById(R.id.submit_button)

    private val registerButton: Button
        get() = findViewById(R.id.register_button)

    private val userName: EditText
        get() = findViewById(R.id.login_user_name)

    private val password: EditText
        get() = findViewById(R.id.login_password)

    private var Attempts = 1

    private val maxAttempts = 3


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        registerButton.setOnClickListener{
            val intent = Intent(this, RegisterActivity::class.java)
            startActivityForResult(intent,2)
        }

        submitButton.setOnClickListener {
            val enteredUsername = userName.text.toString().trim()
            val enteredPassword = password.text.toString().trim()

            //          调用隐藏键盘函数对键盘进行隐藏
            hideKeyboard()

            if(Attempts <= maxAttempts) {
                if (enteredUsername == returnRegisterName && enteredPassword == returnRegisterPassword) {
                    // 登录成功的处理逻辑
                    val intent = Intent(this, WelcomeActivity::class.java)
                    intent.putExtra(LOGIN_NAME_KEY, enteredUsername)
                    startActivity(intent)
                } else {
                    val logintoast = Toast.makeText(
                        this,
                        getString(R.string.login_form_entry_error),
                        Toast.LENGTH_LONG
                    )
                    logintoast.setGravity(Gravity.CENTER, 0, 0)
                    logintoast.show()
                    Attempts += 1
                }
            }else{
                submitButton.isEnabled = false
                val attempttoast = Toast.makeText(
                    this,
                    getString(R.string.attempt_out),
                    Toast.LENGTH_LONG
                )
                attempttoast.setGravity(Gravity.CENTER, 0, 0)
                attempttoast.show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(2){
            2 -> if(resultCode == RESULT_OK){
                returnRegisterName = data?.getStringExtra(REGISTER_NAME_KEY)
                returnRegisterPassword = data?.getStringExtra(REGISTER_PASSWORD_KEY)
            }
        }
    }

    private fun hideKeyboard() {
        if (currentFocus != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
        }
    }

}